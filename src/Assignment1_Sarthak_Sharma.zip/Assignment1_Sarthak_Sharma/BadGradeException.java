package Assignment1_Sarthak_Sharma;

/*
 * Sarthak Sharma
 * PROG24178 JAVA 2 Professor Johnathan Penava 
 * Summary: Custom BadGradeException class 
 * OOP Java 2
 * A custom BadGradeException class 
 */

/**
 *
 * @author SarthaksComp
 */
public class BadGradeException extends Exception{
  public BadGradeException(){
    super();
  }
  public BadGradeException(String message){
    super(message);
  }
  
}

